## Description below of one of my favorite album cuts from Sam Hunt--a perfect amuse bouche of hip hop, country and blues

def Artist():
    print ("Sam Hunt")
def Song():
    print ("Hard To Forget")
def OriginalSource():
    print (1957)

Artist()
Song()
OriginalSource()

"""
My extra credit assigment evaluates the question of "Is 'Hard to Forget' influenced by Kanye's krazy tweets or nah?"
And I print a conditional based on a boolean to give me one possible answer.

"""
hip = 2
hop = 1

if hip > hop:
    print ("Luke Laird loves Kanye so of course 'Hard To Forget' is influenced by Kanye")
else:
    print("Or Nah") 








