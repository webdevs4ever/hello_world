## Description below of one of my favorite album cuts from Sam Hunt--a perfect amuse bouche of hip hop, country and blues
Artist = "Sam Hunt"
Song = "Hard To Forget"
OriginalSource = 1957
OriginalArtist = "Webb Pierce"
Artwork = "HonkyTonk"
Price = 2.50
Platforms = "Apple, Spotify, Songza, YouTube"
Genre = "CountryStrong"
Duration = 300
Producer = "Luke Laird"

print(Artist)
print(Song)
print(OriginalSource)
print(OriginalArtist)
print(Artwork)
print(Price)
print(Platforms)
print(Genre)
print(Duration)
print(Producer)


"""
"Oh baby, you're playing hard to forget"...
Fun Fact #1 about the song "Hard to Forget" is that the original producer heard the song's signature line 
playing from a jukebox and was immediately inspired by Kanye West's "808 and Heartbreak" style to create the
final product--a country music smash.

https://repl.it/@Rasheim/ModernOddballAfkgaming#main.py

"""




